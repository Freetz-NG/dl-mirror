$DebugPreference = "Continue"
$VerbosePreference = "Continue"
