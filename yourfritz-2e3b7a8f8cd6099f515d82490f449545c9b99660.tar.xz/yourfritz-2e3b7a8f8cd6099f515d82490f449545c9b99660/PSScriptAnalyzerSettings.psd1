@{
    ExcludeRules = @('PSAvoidUsingPlainTextForPassword')
}