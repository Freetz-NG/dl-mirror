#define VER_DAT_RAW "Apr 12 2025"
